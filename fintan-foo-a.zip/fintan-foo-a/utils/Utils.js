'use strict'

module.exports = class Utils {
    constructor(log) {
      this.log = log

    }

   do_foo_a(body, cb) {
     this.log.info(">>> In the do_foo_a() function ... ")

     this.do_foo_a_a(body, (body_) => {
       this.do_foo_a_b(body_, (body__) => {
          cb(body__)
       })
     })
   }

   do_foo_a_a(body, cb){
     let obj = this

     let params = JSON.parse("{\"message\":\"The quick brown fox jumped over the lazy dog\"}")

     this.ow.actions.invoke({
  	    blocking: true,
  		  actionName: 'foo_b_a_seq',
  		  params: params
     }).then((param) => {
  	    obj.log.info("Returned from ow.actions.invoke with param : " + JSON.stringify(param))
  		  obj.log.info("Returned from ow.actions.invoke with param.response.result : " + JSON.stringify(param.response.result))
  		  // Return the result of the OpenWhisk call
        let response = "{\"svc\": \"foo_b_a\", \"svc_response\":\"" + param.response.result.payload +  "\"}"
        body.foo.entries[body.foo.entries.length] = JSON.parse(response)
        cb(body)
     }).catch((err) => {
  		  obj.log.info("ERROR Returned from ow.actions.invoke with err : " + JSON.stringify(err))
        let response = "{\"svc\": \"foo_b_a\", \"svc_response\":\"ERROR\"}"
        body.foo.entries[body.foo.entries.length] = JSON.parse(response)
        cb(body)
     })
   }

   do_foo_a_b(body, cb){
     let obj = this

     let params = JSON.parse("{\"num\":999}")

     this.ow.actions.invoke({
  	    blocking: true,
  		  actionName: 'foo_b_b',
  		  params: params
     }).then((param) => {
  	    obj.log.info("Returned from ow.actions.invoke with param : " + JSON.stringify(param))
  		  obj.log.info("Returned from ow.actions.invoke with param.response.result : " + JSON.stringify(param.response.result))
  		  // Return the result of the OpenWhisk call
        let entry = "999 squared = " + param.response.result.sum
        let response = "{\"svc\": \"foo_b_b\", \"svc_response\":\"" + entry +  "\"}"
        body.foo.entries[body.foo.entries.length] = JSON.parse(response)
        cb(body)
     }).catch((err) => {
  		  obj.log.info("ERROR Returned from ow.actions.invoke with err : " + JSON.stringify(err))
        let response = "{\"svc\": \"foo_b_b\", \"svc_response\":\"ERROR\"}"
        body.foo.entries[body.foo.entries.length] = JSON.parse(response)
        cb(body)
     })
   }
}

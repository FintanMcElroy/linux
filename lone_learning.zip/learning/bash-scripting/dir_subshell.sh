#!/bin/bash

echo 'enter a fully qualified dir location'

read DIR

cd $DIR

pwd

ls -l


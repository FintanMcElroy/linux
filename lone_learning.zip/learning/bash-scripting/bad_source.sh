echo 'this is going to do something unexpected!'

exit 0

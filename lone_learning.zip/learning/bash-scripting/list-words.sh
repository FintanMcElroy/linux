#!/bin/bash
# Script to make sure user provided some input and then displays them

# Test whether first argument is empty
if [ -z $1 ] 
then
	echo 'provide words'
	read WORDS
else
	WORDS="$@"
fi

echo 'You provided these words'
for i in $WORDS
do
	echo $i
done

exit 0


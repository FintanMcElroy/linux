# This is intended to be called from another script
# So it does not have a shebang at start and no exit
COLOUR=red

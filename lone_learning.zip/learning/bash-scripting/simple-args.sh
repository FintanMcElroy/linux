#!/bin/bash
# Script that takes 2 arguments and outputs their values

# Note using double quotes so that $ is still evaluated
echo "Hello $1, how are you?"

echo "Hello $2, how are you?"

exit 0

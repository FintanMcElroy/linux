#!/bin/bash
# Script that shows how here documents can be used
# as an alternative to the echo command

# the << means continue until you reach the End-of-msg
cat <<End-of-msg
-------------------------------------------
This is line 1 of the message
This is line 2 of the message
This is the last line of the message
-------------------------------------------
End-of-msg

exit 0

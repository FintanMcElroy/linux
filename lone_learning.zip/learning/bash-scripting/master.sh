#!/bin/bash
# Example script that sources another script

# source the other script - can also use keyword 'source' instead of '.'
. source.sh

echo 'the value of the variable $COLOUR is '$COLOUR

exit 0

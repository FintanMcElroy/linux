#!/bin/bash
# This script copies ~/logs/messages and clears
# the current contents of the file
# Usage: ./clearlogs.sh

# Create and assign a location to a variable
# - note uppercase name is a convention
LOGFILE=~/bash-scripts/logs/messages
# Copy the file
cp $LOGFILE $LOGFILE.old
# Redirect empty contents into the file
cat /dev/null > $LOGFILE
# Echo message to console
echo 'log/messages copied and cleared'
# Exit with RC=0
exit 0

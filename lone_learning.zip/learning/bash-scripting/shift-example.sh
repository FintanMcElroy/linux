#!/bin/bash
# To show the usage of shift and handling large numbers of arguments
echo "The entire arguments list is $*"

echo "The value of \$9 is $9"
echo "The value of \$10 is $10"
# Modern shells understand the use of ${}
echo "The valueof \${10} is ${10}"

# Some older shells may not understand ${} so you have to use shift
shift
echo "After shift the value of \$9 is $9"
echo "After shift the entire arguments list is $*"

exit 0

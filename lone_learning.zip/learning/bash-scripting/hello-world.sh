#!/bin/bash
# This is a comment
clear
echo 'Hello World!'
exit 0

#!/bin/bash

x=$(($1 * $2))

echo $x

exit 0

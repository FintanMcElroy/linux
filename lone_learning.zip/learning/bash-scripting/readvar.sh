#!/bin/bash
# This script using read to get input from user
# Usage: ./readvar.sh

echo 'what is your name?'

read FIRST_NAME LAST_NAME

echo 'Hello '$FIRST_NAME', how is the clan '$LAST_NAME' this fine day?'

exit 0

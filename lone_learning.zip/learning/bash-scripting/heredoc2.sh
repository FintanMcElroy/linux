#!/bin/bash
# Script that shows how here documents can be used
# as an alternative to the echo command

# the << means continue until you reach the End-of-msg
# wall = write all
wall <<End-of-msg
-------------------------------------------
The menu for today is:
1.	Healthy soup and salad
2.	Fish and chips
3.	Steak hash
-------------------------------------------
End-of-msg

exit 0

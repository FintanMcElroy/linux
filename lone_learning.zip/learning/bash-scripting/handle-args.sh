#!/bin/bash
# Script that shows how arguments are handled

echo "\$* gives $*"
echo "\$# gives $#"
echo "\$@ gives $@"
echo "\$0 is $0"

# Showing the interpretation of $*
echo 'About to loop using $* ...'
for i in "$*" # there is a single string so loop will execute only once
do
	echo $i
done

# Showing the interpretation of $@
echo 'About to loop using $@ ...'
for j in "$@" # it is an array of args so each one will be processed
do
	echo $j
done

# Showing that not double quoting S* then processes it as array
echo 'About to loop using $* not in double quotes ...'
for k in $*
do
	echo $k
done

# Showing that not double quoting $@ makes no difference
echo 'About to loop using $@ not in double quotes ...'
for l in $@
do
	echo $l
done

exit 0

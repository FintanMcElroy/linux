#Wed Aug 31 18:54:49 BST 2016
lib/com.ibm.ws.zos.command.processing_1.0.14.jar=e8bb7c01aea1bab1aebce5b6718a3f7a
lib/platform/zosExtensions-1.0.mf=819cdc5896c09c0bd790dc25f388ccdf

#Wed Aug 31 18:54:49 BST 2016
lib/com.ibm.ws.logging_1.0.14.jar=a909836e993dda969cce135de61d8615
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.logging_1.1-javadoc.zip=e786caf35bc42666e1ed9dc744d93854
lib/platform/defaultLogging-1.0.mf=16149f2597cb1d033326df6e3c86a7f7
lib/com.ibm.ws.logging.osgi_1.0.14.jar=9684d336fb4f91cc4e09a3b3beb5d993
dev/spi/ibm/com.ibm.websphere.appserver.spi.logging_1.1.14.jar=ece03d065441379fca0f5f5131e252b1

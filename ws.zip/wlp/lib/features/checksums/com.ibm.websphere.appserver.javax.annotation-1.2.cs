#Wed Aug 31 18:54:50 BST 2016
dev/api/spec/com.ibm.ws.javaee.annotation.1.2_1.0.14.jar=1f8f518480a580f9618f8490e7e6b5f7
lib/features/com.ibm.websphere.appserver.javax.annotation-1.2.mf=5dcd0109311f22ac0c973de5ae2b0935

#Wed Aug 31 18:54:49 BST 2016
lib/features/com.ibm.websphere.appserver.javax.mail-1.5.mf=95f54cdd64db4ab7ea01299086d3582b
lib/com.ibm.ws.javax.mail-1.5_1.5.14.jar=513d02f4e2cb7c372c688f1f91c0a5d6

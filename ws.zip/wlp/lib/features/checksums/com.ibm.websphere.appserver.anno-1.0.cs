#Wed Aug 31 18:54:50 BST 2016
lib/features/com.ibm.websphere.appserver.anno-1.0.mf=9ce5372971006b6546ef6545fa3e4d39
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.anno_1.0-javadoc.zip=106fc16be3f277507214c23c18cfb0e0
lib/com.ibm.ws.anno_1.0.14.jar=a2c6e71dc5286631d197a40c9cf4ff68
dev/spi/ibm/com.ibm.websphere.appserver.spi.anno_1.0.14.jar=a93a3b5956d47ce9e6253eeddd7ee5fd

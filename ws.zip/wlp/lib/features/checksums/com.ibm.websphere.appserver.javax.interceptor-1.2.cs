#Wed Aug 31 18:54:49 BST 2016
dev/api/spec/com.ibm.ws.javaee.interceptor.1.2_1.0.14.jar=69771ca7e51d5d618211b1af36d9fcd1
lib/features/com.ibm.websphere.appserver.javax.interceptor-1.2.mf=6f907070e6f5b21256b659b69fb3014f

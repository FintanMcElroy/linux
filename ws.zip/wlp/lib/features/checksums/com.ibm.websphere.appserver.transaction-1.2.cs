#Wed Aug 31 18:54:50 BST 2016
lib/com.ibm.tx.util_1.0.14.jar=aac10ca18462b85ea255d8e24802f394
lib/com.ibm.ws.tx.jta.extensions_1.0.14.jar=c8b31053dd26515ae0de154294e6648f
lib/com.ibm.ws.recoverylog_1.0.14.jar=e9ee50e581ccb4e4ae143587e4329929
lib/com.ibm.ws.cdi-1.2.interfaces_1.0.14.jar=81b0951087a202cffd30adf1067af2a3
lib/com.ibm.rls.jdbc_1.0.14.jar=30d04fc75b90ef1f949ac69f0e87ad55
dev/spi/ibm/com.ibm.websphere.appserver.spi.transaction_1.1.14.jar=272e01c4e5ae4246139a33a877648988
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.transaction_1.1-javadoc.zip=56dc08bd0c5682e43b62184c8e1a799e
lib/com.ibm.ws.transaction_1.0.14.jar=858655a029719aea841b25e95d676113
lib/com.ibm.tx.jta_1.0.14.jar=52b5e1dac881a3432fd508301c60fbf9
lib/com.ibm.ws.tx.embeddable_1.0.14.jar=7439a159960f97951c510859c8f05b89
lib/features/com.ibm.websphere.appserver.transaction-1.2.mf=a508fd13e0a58b862b3c744b4c67080c
lib/com.ibm.tx.ltc_1.0.14.jar=1eca31752e84e8ac6afde710f6468092
lib/com.ibm.ws.transaction.cdi_1.0.14.jar=290bdcef83f4b8af634203ee88ab8549

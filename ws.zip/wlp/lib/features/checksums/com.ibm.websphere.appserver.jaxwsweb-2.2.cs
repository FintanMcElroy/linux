#Wed Aug 31 18:54:50 BST 2016
lib/features/com.ibm.websphere.appserver.jaxwsweb-2.2.mf=6815f31695af6df4172584f5a49dff41
lib/com.ibm.ws.jaxws.web_1.0.14.jar=61893da47d417a610f5698ec0e6b4918
lib/com.ibm.ws.jaxws.webcontainer_1.0.14.jar=e011d984126176129b3b485a405b7ef4

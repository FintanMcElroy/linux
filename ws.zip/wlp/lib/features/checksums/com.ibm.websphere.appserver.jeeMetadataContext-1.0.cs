#Wed Aug 31 18:54:50 BST 2016
lib/com.ibm.ws.javaee.metadata.context_1.0.14.jar=effb0b3db778fc70867eae5ddddae8e8
lib/features/com.ibm.websphere.appserver.jeeMetadataContext-1.0.mf=daadd0597390d2e11364a51a75293b8e

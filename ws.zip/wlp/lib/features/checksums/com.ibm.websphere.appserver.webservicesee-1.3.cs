#Wed Aug 31 18:54:50 BST 2016
dev/api/spec/com.ibm.ws.javaee.jaxws.2.2_1.0.14.jar=a12f008fdb65dc6d7461cbb604848073
lib/com.ibm.ws.webservices.javaee.common_1.0.14.jar=384f994c60922b2f2c212bea898d41f9
lib/com.ibm.ws.javaee.ddmodel.ws_1.0.14.jar=3851b7c7261dbfbe9febaa56043e97ff
lib/features/com.ibm.websphere.appserver.webservicesee-1.3.mf=7a7a8dc1594e5966805b618322f77ea9

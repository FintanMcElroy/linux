'use strict'
const uuid = require('node-uuid')

module.exports = class Credentials {
    constructor(appEnv, log) {
           this.appEnv = appEnv
           this.log = log
    }

   getCredentialsMessageHub (cb){
     // Message Hub service credentials
     const mhServiceName = 'fintan-message-hub'
     let mhService = {}
     let obj = this

     // Get the configuration internally defined in Bluemix
     const baseConfig = this.appEnv.getServices(mhServiceName)
     // Check in case we are running locally
     if (!baseConfig || Object.keys(baseConfig).length === 0) {
       // Get the local credentials
       this.getCredentialsLocal('./creds/mh_credentials.json', (creds) => {
         mhService.credentials = creds
         mhService.credentials.id = 'foo_a_a_' + uuid.v4().substring(0, 7)
         obj.log.info(`mqlight_lookup_url = ${mhService.credentials.mqlight_lookup_url}`)
         obj.log.info(`user = ${mhService.credentials.user}`)
         obj.log.info(`password = ${mhService.credentials.password}`)
         obj.log.info(`id = ${mhService.credentials.id}`)
         cb(mhService.credentials)
       })
     }
     // VCAP_SERVICES stored in Bluemix
     else {
       mhService = baseConfig[mhServiceName]
       mhService.credentials.id = 'foo_a_a_' + uuid.v4().substring(0, 7)
       obj.log.info(`mqlight_lookup_url = ${mhService.credentials.mqlight_lookup_url}`)
       obj.log.info(`user = ${mhService.credentials.user}`)
       obj.log.info(`password = ${mhService.credentials.password}`)
       obj.log.info(`id = ${mhService.credentials.id}`)
       cb(mhService.credentials)
     }
   }

   getCredentialsLocal(file, cb){
     const jsonfile = require('jsonfile')
     jsonfile.readFile(file, function(err, obj) {
       if (err) {
         obj.log.error("Error reading credentials file ", err)
       }
       cb(obj.credentials)
     })
   }
}

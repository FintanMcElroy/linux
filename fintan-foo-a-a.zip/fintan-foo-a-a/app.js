'use strict'
const express = require('express')
const cfenv = require('cfenv')
const appEnv = cfenv.getAppEnv()
const app = express()
const bodyParser = require('body-parser')
const Log = require('log')
const log = new Log("info")
const Utils = require('./utils/Utils.js')

// Need body-parser to access req.body in the POST method
app.use(bodyParser.json()) // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })) // support encoded bodies

// Needs to handle a post of Foo structure and then call node.js on Docker endpoints svc/foo_a_a and svc/foo_a_b
app.post('/svc/foo_a_a', (req, res) => {
	log.info(">>> app.post(/svc/foo_a_a) ENTRY ... ")

	const utils = new Utils(log)
	utils.do_foo_a_a(req.body, (response) => {
		res.contentType('application/json')
		res.send(response)
	})
})

const dockerPort = 8080
app.listen(dockerPort, '0.0.0.0', () => {
  log.info(`server starting on ${appEnv.url}`)
})

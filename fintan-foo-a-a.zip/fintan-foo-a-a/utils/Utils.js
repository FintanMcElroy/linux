'use strict'

module.exports = class Utils {
    constructor(log) {
      this.log = log

    }

   do_foo_a_a(body, cb) {
     this.log.info(">>> In the do_foo_a_a() function ... ")

     let response = "{\"svc\": \"foo_a_a\", \"svc_response\":\"Dummy response from foo_a_a\"}"
     body.foo.entries[body.foo.entries.length] = JSON.parse(response)
     cb(body)
   }

}

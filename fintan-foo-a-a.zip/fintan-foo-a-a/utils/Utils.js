'use strict'
const mqlight = require('mqlight')
const cfenv = require('cfenv')
const appEnv = cfenv.getAppEnv()
const Credentials = require('../creds/Credentials.js')

module.exports = class Utils {
    constructor(log) {
      this.log = log
    }

   do_foo_a_a(body, cb) {
     this.log.info(">>> In the do_foo_a_a() function ... ")

     let obj = this
     let creds = new Credentials(appEnv, this.log)
     creds.getCredentialsMessageHub((credsMH) => {
       // Set up connectivity options
       let opts = {}
       opts.service = credsMH.mqlight_lookup_url
       opts.user = credsMH.user
       opts.password = credsMH.password
       opts.id = credsMH.id

       // Set up the connection to Message Hub
       let mqlightClient = mqlight.createClient(opts, (err) => {
         if (err) {
           obj.log.error(`svc/foo_a_a connection to ${opts.service} using client-id ${opts.id} failed: ` + err)
         } else {
           obj.log.info(`svc/foo_a_a connected to ${opts.service} using client-id ${opts.id} `)
         }

         // Publish event
         let eventData = { "status" : "hello message hub from svc foo_a_a"}
         eventData = JSON.stringify(eventData)
         mqlightClient.send('/svc/foo_a_a/event', eventData, () => {
           obj.log.info(`svc/foo_a_a published a status to the topic `)

           // Disconnect from Message Hub - gives an error in this context
           //mqlightClient.disconnect()

           let response = "{\"svc\": \"foo_a_a\", \"svc_response\":\"foo_a_a published to topic svc/foo_a_a\"}"
           body.foo.entries[body.foo.entries.length] = JSON.parse(response)
           cb(body)
       }) // end message hub publish
     })
   })
 }
}
